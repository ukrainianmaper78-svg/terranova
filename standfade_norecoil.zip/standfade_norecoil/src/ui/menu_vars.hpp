#pragma once

#include "imgui.h"

// ─── Settings ───
inline int    s_lang           = 1;     // 0 = ru, 1 = en
inline int    s_scrollbar_size = 24;

// ─── Watermark (hardcoded defaults, no menu controls) ───
inline bool   opt_wm             = true;
inline bool   opt_wm_icons       = true;
inline bool   opt_wm_show_site   = true;
inline bool   opt_wm_show_type   = true;
inline bool   opt_wm_show_fps    = true;
inline bool   opt_wm_show_time   = true;
inline bool   opt_wm_show_version = true;
inline int    s_wm_side          = 0;        // 0 = left
inline ImVec4 s_wm_col           = ImVec4(1.f, 1.f, 1.f, 1.f);
inline float  s_wm_scale         = 1.f;
