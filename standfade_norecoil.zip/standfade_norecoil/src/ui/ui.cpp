#include "ui.hpp"

#include "widgets.hpp"
#include "fonts.hpp"
#include "cfg.hpp"
#include "lang.hpp"
#include "menu_vars.hpp"
#include "watermark.hpp"

#include "bytes.hpp"
#include "font_awesome.hpp"
#include "notifications.hpp"
#include "log.hpp"
#include <cstdio>
#include <cstdlib>

using namespace ImGui;

template <typename T>
inline T _clamp(const T& n, const T& lower, const T& upper) {
    return std::max(lower, std::min(n, upper));
}
inline float lerp(float a, float b, float f) {
    return _clamp<float>(a + f * (b - a), a > b ? b : a, a > b ? a : b);
}

void custom_interface_t::initialize() {
    auto& style = GetStyle();
    auto& col = GetStyle().Colors;

    c_utils->accent = cfg::style::accent;

    style.ScrollbarSize = 6;
    style.ScrollbarRounding = 3;
    style.FrameRounding = 4;
    style.WindowRounding = 6;
    style.WindowBorderSize = 0;
    style.ItemSpacing = { 10, 10 };
    style.WindowMinSize = { 2, 2 };

    col[ImGuiCol_Border]      = ImColor(28, 28, 28).Value;
    col[ImGuiCol_WindowBg]    = ImColor(16, 16, 16).Value;
    col[ImGuiCol_ChildBg]     = { 0, 0, 0, 0 };
    col[ImGuiCol_ScrollbarBg] = ImColor(10, 10, 10).Value;

    ImGuiIO& io_pre = ImGui::GetIO();
    float sw_pre = io_pre.DisplaySize.x;
    float sh_pre = io_pre.DisplaySize.y;
    float adaptive = 2.f;
    if (sw_pre > 1.f && sh_pre > 1.f) {
        float by_w = sw_pre / 800.f;
        float by_h = sh_pre / 520.f;
        adaptive = (by_w < by_h) ? by_w : by_h;
        if (adaptive > 2.f) adaptive = 2.f;
        if (adaptive < 0.6f) adaptive = 0.6f;
    }
    c_scale->current_scale = adaptive;

    style.ScaleAllSizes(c_scale->current_scale);
}

void custom_interface_t::initialize_fonts() {
    auto& io = GetIO();

    ImFontConfig cfg;

    this->fonts.regular = io.Fonts->AddFontFromMemoryTTF(montserrat_med, sizeof montserrat_med, 14.f * c_scale->current_scale, &cfg, io.Fonts->GetGlyphRangesCyrillic());

    extern ImFont* espFont;
    this->fonts.esp_font = espFont;

    io.FontDefault = this->fonts.regular;

    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.SizePixels = 14.f * c_scale->current_scale;
    static const ImWchar icon_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0x0 };
    ImFontConfig icons_config2;
    icons_config2.SizePixels = 26 * c_scale->current_scale;

    this->fonts.icons    = io.Fonts->AddFontFromMemoryTTF(font_awesome_binary, sizeof font_awesome_binary, 9 * c_scale->current_scale, &icons_config, icon_ranges);
    this->fonts.bold     = io.Fonts->AddFontFromMemoryTTF(montserrat_med, sizeof montserrat_med, 14.f * c_scale->current_scale, &cfg, io.Fonts->GetGlyphRangesCyrillic());
    this->fonts.big_and_bold = io.Fonts->AddFontFromMemoryTTF(montserrat_med, sizeof montserrat_med, 20 * c_scale->current_scale, &cfg, io.Fonts->GetGlyphRangesCyrillic());
    this->fonts.gondon   = io.Fonts->AddFontFromMemoryTTF(font_awesome_binary, sizeof font_awesome_binary, 16 * c_scale->current_scale, &icons_config2, icon_ranges);

    this->tabs = {
        {"Visuals",  nullptr, 0},
        {"Aimbot",   nullptr, 0},
        {"Misc",     nullptr, 0},
        {"Rage",     nullptr, 0},
        {"Configs",  nullptr, 0},
        {"Settings", nullptr, 0},
        {"Credits",  nullptr, 0},
    };

    this->subtabs = {
        {"ESP", 0},
    };

    c_widgets->arrow_elem.font  = this->fonts.icons;
    c_widgets->arrow_elem.glyph    = ICON_FA_ANGLE_DOWN;
    c_widgets->arrow_elem.glyph_up = ICON_FA_ANGLE_UP;
}

// ── Tab content ─────────────────────────────────────────────────────────────
namespace menu_tabs {

static void color4(const char* l, ImVec4* c) {
    char b[64]; snprintf(b, sizeof(b), "%s##%p", l, (void*)c);
    c_widgets->color_edit_4(b, (float*)c);
}

static const char* langs[] = { "русский", "english" };

static void settings_tab() {
    color4(g_lang->accent, &cfg::style::accent);
    c_utils->accent = cfg::style::accent;

    if (c_widgets->combo(g_lang->language, &s_lang, langs, IM_ARRAYSIZE(langs)))
        apply_lang(s_lang);

    ImGui::Spacing();
    ImGui::Spacing();

    if (c_widgets->button(g_lang->exit_cheat)) {
        exit(0);
    }
}

static void credits_tab() {
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.5f, 0.5f, 0.5f, 1.f));
    ImGui::TextWrapped("%s", g_lang->thanks);
    ImGui::PopStyleColor();
    ImGui::TextWrapped("@DanyaVoredom // github.com/FANATFANATA");
    ImGui::TextWrapped("@panwoc // github.com/player901090-design");
    ImGui::TextWrapped("and @WhyIW // github.com/WhyIW-TG");
    ImGui::TextWrapped("silent aim by @NEWolsaw");
}

} // namespace menu_tabs

void custom_interface_t::render(void *_vars) {
    (void)_vars;

    apply_lang(s_lang);

    if (!fonts.regular) return;

    if (s_lang == 0 && fonts.esp_font) {
        ImGui::GetIO().FontDefault = fonts.esp_font;
        ImGui::PushFont(fonts.esp_font);
    } else {
        ImGui::GetIO().FontDefault = fonts.regular;
        ImGui::PushFont(fonts.regular);
    }

    GetStyle().ScrollbarSize = s_scrollbar_size * c_scale->current_scale;

    logs::render(ImGui::GetIO().DisplaySize, ImGui::GetBackgroundDrawList(), 25);

    ImGui::RenderNotifications();

    PushStyleVar(ImGuiStyleVar_WindowPadding, { 0, 0 });

    static ImVec2 main_window_pos{};

    static animation child_bg{};

    child_bg.update(1);

    SetNextWindowSize({ c_scale->get(620), c_scale->get(370) - c_scale->get(45) });

    Begin("##t.me/imguiseller", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBringToFrontOnFocus); {
        GetWindowDrawList()->AddRectFilled(GetWindowPos(), GetWindowPos() + GetWindowSize(), ImColor(15, 15, 15), GetStyle().WindowRounding, ImDrawFlags_RoundCornersBottom);

        main_window_pos = GetWindowPos();

        auto& col = GetStyle().Colors;
        col[ImGuiCol_ScrollbarGrabActive]  = c_utils->get_accent_imv4(GetStyle().Alpha, 0.8f);
        col[ImGuiCol_ScrollbarGrabHovered] = c_utils->get_accent_imv4(GetStyle().Alpha, 0.8f);
        col[ImGuiCol_ScrollbarGrab]        = c_utils->get_accent_imv4(GetStyle().Alpha, 0.8f);

        /* tabs */ {
            BeginChild("##tabs", { c_scale->get(150), GetWindowSize().y }, false);

            static animation_vec2 background{};

            SetCursorPosY(GetCursorPosY() + c_scale->get(10));

            const ImVec2& size = { GetContentRegionAvail().x, c_scale->get(30) };

            GetWindowDrawList()->AddRectFilled(
                GetWindowPos() + background.value + ImVec2(c_scale->get(9), 0),
                GetWindowPos() + background.value + size - ImVec2(c_scale->get(9), 0),
                static_cast<ImColor>(c_utils->process_alpha(ImColor(20, 20, 20).Value, GetStyle().Alpha)),
                GetStyle().WindowRounding
            );

            PushStyleVar(ImGuiStyleVar_ItemSpacing, { c_scale->get(10), 0 });

            for (int it{}; it < (int)this->tabs.size(); it++) {
                auto& tab = this->tabs[it];

                const ImVec2& current_cursor        = GetCursorScreenPos();
                const ImVec2& current_cursor_window = GetCursorPos();

                if (InvisibleButton(tab.name, size)) {
                    this->current_tab    = it;
                    this->current_subtab = tab.default_sub;
                    child_bg.value       = 0;
                }

                const ImRect btn_rect{
                    current_cursor + ImVec2(c_scale->get(9), 0),
                    current_cursor + size - ImVec2(c_scale->get(9), 0)
                };

                const auto& draw_list  = GetWindowDrawList();
                const auto& label_size = CalcTextSize(tab.name);

                tab.text.interpolate(ImColor(255, 255, 255).Value, ImColor(150, 150, 150).Value, (it == this->current_tab));
                tab._icon.interpolate(c_utils->get_accent_imv4(GetStyle().Alpha), ImColor(150, 150, 150).Value, (it == this->current_tab));

                const ImVec2 text_pos{
                    btn_rect.Min.x + btn_rect.GetHeight() / 2 - label_size.y / 2,
                    btn_rect.GetCenter().y - label_size.y / 2,
                };

                if (tab.icon)
                    draw_list->AddText(text_pos - ImVec2(0, 1), static_cast<ImColor>(c_utils->process_alpha(tab._icon.value, GetStyle().Alpha)), tab.icon);

                draw_list->AddText(text_pos + ImVec2(c_scale->get(20), 0) - ImVec2(0, 1), static_cast<ImColor>(c_utils->process_alpha(tab.text.value, GetStyle().Alpha)), tab.name);

                if (this->current_tab == it)
                    background.update(current_cursor_window);
            }

            PopStyleVar();

            EndChild();

            GetWindowDrawList()->AddRectFilled(GetWindowPos(), GetWindowPos() + ImVec2(c_scale->get(150), GetWindowSize().y), ImColor(16, 16, 16), GetStyle().WindowRounding, ImDrawFlags_RoundCornersBottomLeft);
            GetWindowDrawList()->AddLine(GetWindowPos() + ImVec2(c_scale->get(150), 0), GetWindowPos() + ImVec2(c_scale->get(150), GetWindowSize().y), ImColor(24, 24, 24), c_scale->get(1));
        }

        /* main content */ {
            PushStyleVar(ImGuiStyleVar_Alpha, child_bg.value * GetStyle().Alpha);

            SetCursorPos({ c_scale->get(150) + c_scale->get(10), 0 + 1 + (c_scale->get(20) * (1.0f - child_bg.value)) });

            const float& width = GetContentRegionAvail().x;

            if (this->current_tab != 999) {
                BeginChild("##container_main", { width, GetContentRegionAvail().y - c_scale->get(1) }, false, ImGuiWindowFlags_AlwaysVerticalScrollbar);
                Spacing();
                switch (this->current_tab) {
                    case 0: /* Visuals — empty */  break;
                    case 1: /* Aimbot  — empty */  break;
                    case 2: {
                        auto& v = cvars::vars();
                        c_widgets->toggle("No Recoil", &v.bools.no_recoil);
                        break;
                    }
                    case 3: /* Rage    — empty */  break;
                    case 4: /* Configs — empty */  break;
                    case 5: menu_tabs::settings_tab(); break;
                    case 6: menu_tabs::credits_tab();  break;
                }
                Spacing();
                EndChild();
            } else {
                BeginChild("##container_settings", { width, GetContentRegionAvail().y - c_scale->get(1) }, false, ImGuiWindowFlags_AlwaysVerticalScrollbar);
                Spacing();
                menu_tabs::settings_tab();
                Spacing();
                EndChild();
            }

            PopStyleVar();
        }

        End();
    }

    SetNextWindowPos(main_window_pos - ImVec2(0, c_scale->get(70)));
    SetNextWindowSize({ c_scale->get(620), c_scale->get(70) });

    Begin("##heading", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoMove); {
        GetWindowDrawList()->AddRectFilled(GetWindowPos(), GetWindowPos() + GetWindowSize(), ImColor(15, 15, 15), GetStyle().WindowRounding, ImDrawFlags_RoundCornersTop);

        int heading_height = c_scale->get(70);
        const auto& base   = GetWindowPos();

        const ImRect h_rect{
            base,
            base + ImVec2(GetWindowSize().x, heading_height)
        };

        auto draw_list = GetWindowDrawList();

        const float ccx = h_rect.Min.x + (c_scale->get(150) * 0.5f);

        PushFont(this->fonts.bold);
        const char* logo_text = "nez3r.pw";
        const ImVec2& logo_sz = CalcTextSize(logo_text);
        const ImVec2& beta_sz = CalcTextSize("beta");

        const float beta_y = h_rect.Min.y + c_scale->get(3);
        draw_list->AddText({ ccx - beta_sz.x * 0.5f, beta_y }, ImColor(255, 0, 0), "beta");
        draw_list->AddText({ ccx - logo_sz.x * 0.5f, beta_y + beta_sz.y + c_scale->get(2) }, c_utils->get_accent_imc(), logo_text);
        PopFont();

        GetWindowDrawList()->AddLine({ GetWindowPos().x + c_scale->get(150), GetWindowPos().y }, { GetWindowPos().x + c_scale->get(150), GetWindowPos().y + GetWindowSize().y - 1 }, ImColor(28, 28, 28), c_scale->get(1));
        GetWindowDrawList()->AddLine({ GetWindowPos().x, GetWindowPos().y + GetWindowSize().y - 1 }, GetWindowPos() + GetWindowSize() - ImVec2(0, 1), ImColor(28, 28, 28), c_scale->get(1));

        SetCursorPos({ c_scale->get(150) + GetStyle().ItemSpacing.x + c_scale->get(16), 10 });

        /* subtabs */ {
            for (int it{}; it < (int)subtabs.size(); it++) {
                if (subtabs[it].parent != current_tab) continue;

                PushStyleVar(ImGuiStyleVar_ItemSpacing, { c_scale->get(8), 0 });

                SetCursorPosY(c_scale->get(10));

                const auto& current_cursor = GetCursorScreenPos();
                const auto& btn_sz = ImVec2(CalcTextSize(subtabs[it].name).x + c_scale->get(6), c_scale->get(50));

                if (InvisibleButton(subtabs[it].name, btn_sz)) {
                    current_subtab  = it;
                    child_bg.value  = 0;
                }

                const ImRect btn_rect = {
                    current_cursor,
                    current_cursor + btn_sz
                };

                subtabs[it].text.interpolate(ImColor(255, 255, 255).Value, ImColor(150, 150, 150).Value, (it == this->current_subtab));
                subtabs[it]._icon.interpolate(c_utils->get_accent_imv4(GetStyle().Alpha), ImColor(150, 150, 150).Value, (it == this->current_subtab));

                GetWindowDrawList()->AddText(btn_rect.GetCenter() - CalcTextSize(subtabs[it].name) / 2, ImColor(subtabs[it].text.value), subtabs[it].name);
                GetWindowDrawList()->AddLine(
                    { btn_rect.Min.x, btn_rect.GetCenter().y + CalcTextSize(subtabs[it].name).y / 2 + c_scale->get(2) },
                    { btn_rect.Max.x, btn_rect.GetCenter().y + CalcTextSize(subtabs[it].name).y / 2 + c_scale->get(2) },
                    ImColor(subtabs[it]._icon.value), c_scale->get(2)
                );

                SameLine();

                PopStyleVar();
            }

            const ImVec2 btn_sz = { GetWindowSize().y, GetWindowSize().y };
            SetCursorPos({ GetWindowSize().x - btn_sz.x, 0 });
            const auto& current_cursor_gear = GetCursorScreenPos();
            if (InvisibleButton(ICON_FA_GEAR, btn_sz)) {
                current_tab    = 5;
                child_bg.value = 0;
            }
            const ImRect btn_rect_gear = {
                current_cursor_gear,
                current_cursor_gear + btn_sz
            };
            const auto& ic_sz = fonts.gondon->CalcTextSizeA(16 * c_scale->current_scale, FLT_MAX, 0, ICON_FA_GEAR);
            GetWindowDrawList()->AddText(fonts.gondon, 16 * c_scale->current_scale, btn_rect_gear.GetCenter() - ic_sz / 2, ImColor(255, 255, 255, 100), ICON_FA_GEAR);
        }

        End();
    }

    ImGui::PopFont();

    watermark::render();

    PopStyleVar();
}
