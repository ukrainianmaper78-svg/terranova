#pragma once

#include "../other/memory.hpp"
#include "../protect/oxorany.hpp"
#include "../ui/vars.h"
#include <stdint.h>

struct matrix {
    float m11, m12, m13, m14;
    float m21, m22, m23, m24;
    float m31, m32, m33, m34;
    float m41, m42, m43, m44;
};

// ─── Stand Fade dump offsets (libil2cpp.so, Dump10) ─────────────────────────
//
//  PlayerController (Axlebolt.Standoff.Player.PlayerController : PunBehaviour)
//    +0x58  WeaponryController* (backing field <FBBKEBMLKLA>k__BackingField)
//
//  WeaponryController
//    +0x90  WeaponController*   (backing field <KJFNIALAKNH>k__BackingField  — current weapon)
//
//  WeaponController (abstract base)
//    +0x68  WeaponParameters*   (backing field <NPLINFFEJDM>k__BackingField)
//           cast → GunParameters when weapon is a gun
//
//  GunParameters : WeaponParameters
//    +0xA8  int   _recoilControl
//    +0xB0  RecoilParameters*  _recoilParameters
//
//  RecoilParameters (plain class, not MonoBehaviour — direct field access)
//    +0x10  float horizontalRange
//    +0x14  float verticalRange
//    +0x38  float maxFallbackDuration
//    +0x48  float cameraDeviationCoeff
//    +0x4C  float maxApproachSpeed
//    +0x50  float recoilAccelDuration
//    +0x54  float recoilAccelStep
//
//  GunController : WeaponController
//    +0x1A8 AccuracyData*  KABEIDLFFHC  (live per-shot accuracy state)
//
//  AccuracyData
//    +0x10  float AccuracyAngle
//    +0x14  float RecoilAngle
//
//  Local player factory (class FKFMGOIEJNL, RVA 0x15104A4):
//    returns GameObject* via Resources.Load + FindObjectOfType path
//    we resolve it through PhotonNetwork.player tag or simply walk
//    the static GameController singleton.
//
//  GameController (Axlebolt.Standoff.GameController : PunBehaviour)
//    static field <CIFLBHIJALP>k__BackingField at static data — we use
//    the il2cpp class metadata to get it; simpler: scan PlayerController
//    list from WeaponryController dictionary or use the FKFMGOIEJNL factory.
//
//  Practical approach used here:
//    We call the static helper FKFMGOIEJNL$$EJFHKLBKOFK (RVA 0x15104A4)
//    which returns the local PlayerController* via il2cpp function call
//    through the lib base.
//
// ────────────────────────────────────────────────────────────────────────────

namespace offsets {
    // PlayerController field offsets
    constexpr uint64_t PC_weaponry_ctrl     = 0x58;   // WeaponryController*

    // WeaponryController field offsets
    constexpr uint64_t WRC_current_weapon   = 0x90;   // WeaponController* (current)

    // WeaponController field offsets
    constexpr uint64_t WC_weapon_params     = 0x68;   // WeaponParameters* → GunParameters*

    // GunParameters field offsets
    constexpr uint64_t GP_recoil_ctrl       = 0xA8;   // int   _recoilControl
    constexpr uint64_t GP_recoil_params     = 0xB0;   // RecoilParameters*

    // GunController field offsets
    constexpr uint64_t GC_accuracy_data     = 0x1A8;  // AccuracyData*

    // RecoilParameters field offsets (plain class, layout starts at 0x10 after Il2CppObject header)
    constexpr uint64_t RP_horizontal_range  = 0x10;
    constexpr uint64_t RP_vertical_range    = 0x14;
    constexpr uint64_t RP_max_fallback_dur  = 0x38;
    constexpr uint64_t RP_cam_dev_coeff     = 0x48;
    constexpr uint64_t RP_max_approach_spd  = 0x4C;
    constexpr uint64_t RP_accel_duration    = 0x50;
    constexpr uint64_t RP_accel_step        = 0x54;

    // AccuracyData field offsets
    constexpr uint64_t AD_accuracy_angle    = 0x10;
    constexpr uint64_t AD_recoil_angle      = 0x14;

    // il2cpp static method RVAs — called as func ptr (proc::lib + rva)
    // FKFMGOIEJNL$$EJFHKLBKOFK — returns local PlayerController*
    constexpr uint64_t RVA_get_local_player = 0x15104A4;
}

// ─── No-recoil state ─────────────────────────────────────────────────────────
namespace nr {
    // Cached pointers — reset when weapon changes
    inline uint64_t last_weapon      = 0;
    inline uint64_t recoil_params    = 0;
    inline uint64_t accuracy_data    = 0;

    // Original values (restored when feature disabled)
    inline float orig_h_range        = 0.f;
    inline float orig_v_range        = 0.f;
    inline float orig_fallback       = 0.f;
    inline float orig_cam_dev        = 0.f;
    inline float orig_approach       = 0.f;
    inline float orig_accel_dur      = 0.f;
    inline float orig_accel_step     = 0.f;
    inline bool  saved               = false;
}

namespace game {
    inline int tick       = 0;
    inline int fail_count = 0;
    inline int check_tick = 0;

    inline bool valid() {
        if (proc::pid <= 0) {
            proc::pid = get_pid();
            if (proc::pid <= 0) return false;
        }

        if (proc::lib == 0) {
            proc::lib = get_lib();
            if (proc::lib != 0) init_mem();
            return false;
        }

        tick++;
        if (tick >= 60) {
            int p = get_pid();
            if (p != proc::pid) {
                if (proc::pm >= 0) { sys::close(proc::pm); proc::pm = -1; }
                proc::pid = p;
                proc::lib = 0;
                tick = 0;
                return false;
            }
            tick = 0;
        }

        return true;
    }

    inline void check_lib() {
        check_tick++;
        if (check_tick >= 60) {
            uint64_t lib = get_lib();
            if (lib != 0 && lib != proc::lib) {
                proc::lib = lib;
                if (proc::pm >= 0) { sys::close(proc::pm); proc::pm = -1; }
                init_mem();
            }
            check_tick = 0;
        }
    }

    inline void init() {
        proc::pid = get_pid();
        if (proc::pid > 0) {
            proc::lib = get_lib();
            if (proc::lib != 0) init_mem();
        }
    }

    // ── Resolve local PlayerController* ──────────────────────────────────────
    // Calls FKFMGOIEJNL$$EJFHKLBKOFK (il2cpp static method).
    // Signature: PlayerController* fn(Il2CppString* tag)
    // We pass nullptr — the default parameter "Player/Player" is baked into
    // the stub as a fallback, so null tag causes it to use the default path.
    inline uint64_t get_local_player() {
        if (proc::lib == 0) return 0;
        using fn_t = uint64_t(*)(uint64_t);
        auto fn = reinterpret_cast<fn_t>(proc::lib + offsets::RVA_get_local_player);
        // We can't call into the target process directly from an external
        // injected .so — but we ARE injected (libil2cpp.so context).
        // Call it directly; il2cpp is already mapped in our process space.
        uint64_t result = 0;
        // Guard: proc::lib is our own mapped base, fn lives there
        if (addr_valid(reinterpret_cast<uint64_t>(fn))) {
            result = fn(0); // null string → default tag
        }
        return result;
    }

    // ── No-recoil tick — call every frame while game is valid ────────────────
    inline void no_recoil_tick() {
        auto& vars = cvars::vars();
        const bool want = vars.bools.no_recoil;

        // ── Resolve chain ──────────────────────────────────────────────────
        uint64_t local_pc = get_local_player();
        if (!addr_valid(local_pc)) {
            nr::last_weapon = 0;
            return;
        }

        uint64_t weaponry  = rpm<uint64_t>(local_pc + offsets::PC_weaponry_ctrl);
        if (!addr_valid(weaponry)) return;

        uint64_t weapon    = rpm<uint64_t>(weaponry + offsets::WRC_current_weapon);
        if (!addr_valid(weapon)) {
            nr::last_weapon = 0;
            return;
        }

        uint64_t wp        = rpm<uint64_t>(weapon + offsets::WC_weapon_params);
        if (!addr_valid(wp)) return;

        uint64_t rp        = rpm<uint64_t>(wp + offsets::GP_recoil_params);
        if (!addr_valid(rp)) return;

        // ── Weapon changed — re-save originals ────────────────────────────
        if (weapon != nr::last_weapon) {
            nr::last_weapon   = weapon;
            nr::recoil_params = rp;
            nr::accuracy_data = rpm<uint64_t>(weapon + offsets::GC_accuracy_data);
            nr::saved         = false;
        }

        if (!nr::saved) {
            nr::orig_h_range    = rpm<float>(rp + offsets::RP_horizontal_range);
            nr::orig_v_range    = rpm<float>(rp + offsets::RP_vertical_range);
            nr::orig_fallback   = rpm<float>(rp + offsets::RP_max_fallback_dur);
            nr::orig_cam_dev    = rpm<float>(rp + offsets::RP_cam_dev_coeff);
            nr::orig_approach   = rpm<float>(rp + offsets::RP_max_approach_spd);
            nr::orig_accel_dur  = rpm<float>(rp + offsets::RP_accel_duration);
            nr::orig_accel_step = rpm<float>(rp + offsets::RP_accel_step);
            nr::saved           = true;
        }

        if (want) {
            // ── Zero all recoil contribution fields ───────────────────────
            const float zero = 0.f;
            wpm<float>(rp + offsets::RP_horizontal_range, zero);
            wpm<float>(rp + offsets::RP_vertical_range,   zero);
            wpm<float>(rp + offsets::RP_max_fallback_dur, zero);
            wpm<float>(rp + offsets::RP_cam_dev_coeff,    zero);
            wpm<float>(rp + offsets::RP_max_approach_spd, zero);
            wpm<float>(rp + offsets::RP_accel_duration,   zero);
            wpm<float>(rp + offsets::RP_accel_step,       zero);

            // Zero live AccuracyData (per-shot recoil angle accumulator)
            if (addr_valid(nr::accuracy_data)) {
                wpm<float>(nr::accuracy_data + offsets::AD_accuracy_angle, zero);
                wpm<float>(nr::accuracy_data + offsets::AD_recoil_angle,   zero);
            }
        } else if (nr::saved) {
            // ── Restore originals ─────────────────────────────────────────
            wpm<float>(rp + offsets::RP_horizontal_range, nr::orig_h_range);
            wpm<float>(rp + offsets::RP_vertical_range,   nr::orig_v_range);
            wpm<float>(rp + offsets::RP_max_fallback_dur, nr::orig_fallback);
            wpm<float>(rp + offsets::RP_cam_dev_coeff,    nr::orig_cam_dev);
            wpm<float>(rp + offsets::RP_max_approach_spd, nr::orig_approach);
            wpm<float>(rp + offsets::RP_accel_duration,   nr::orig_accel_dur);
            wpm<float>(rp + offsets::RP_accel_step,       nr::orig_accel_step);
        }
    }
}
